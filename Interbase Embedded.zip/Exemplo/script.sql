/*
This script performs column-level encryption on EMPLOYEE (SALARY)
Make sure you have copied employee.gdb to emp_column_encr.ib
*/

/* # Enable Embedded User Authentication and create users.
   SYSDSO: for encryption management
   HR_EMP: HR Dept. employee. Privilege to see "salary" info.
   NEW_EMP: New employee. No privilege to see "salary" info.
*/
CONNECT 'c:\data\employee_col_encrypt.ib' USER 'sysdba' PASSWORD 'masterkey';
ALTER DATABASE ADD ADMIN OPTION;
CREATE USER SYSDSO SET PASSWORD 'sysdso';
CREATE USER HR_EMP SET PASSWORD 'hr_emp';
CREATE USER NEW_EMP SET PASSWORD 'new_emp';
CREATE USER SALES_EMP SET PASSWORD 'sales_emp';
COMMIT;


/* # Create encryptions */
CONNECT 'c:\data\employee_col_encrypt.ib' USER 'sysdso' PASSWORD 'sysdso';
ALTER DATABASE SET SYSTEM ENCRYPTION PASSWORD 'Secret Password';
CREATE ENCRYPTION hr_key FOR DES WITH LENGTH 56 BITS;
CREATE ENCRYPTION sales_key FOR AES WITH LENGTH 256 BITS;
/* Password protected Encryption key required for database backup */
CREATE ENCRYPTION backup_key FOR AES WITH LENGTH 256 BITS PASSWORD 'backup_password';
GRANT ENCRYPT ON ENCRYPTION backup_key TO SYSDBA;
GRANT ENCRYPT ON ENCRYPTION hr_key TO SYSDBA;
GRANT ENCRYPT ON ENCRYPTION sales_key TO SYSDBA;
COMMIT;

/* # Encrypt EMPLOYEE(SALARY) */
CONNECT 'c:\data\employee_col_encrypt.ib' USER 'sysdba' PASSWORD 'masterkey';
ALTER TABLE EMPLOYEE ALTER COLUMN SALARY ENCRYPT WITH hr_key;
ALTER TABLE EMPLOYEE ALTER COLUMN SALARY DECRYPT DEFAULT 0;
GRANT DECRYPT(salary) ON EMPLOYEE TO HR_EMP;
ALTER TABLE EMPLOYEE ALTER COLUMN phone_ext ENCRYPT WITH sales_key;
ALTER TABLE EMPLOYEE ALTER COLUMN phone_ext DECRYPT DEFAULT 0;
GRANT DECRYPT(phone_ext) ON EMPLOYEE TO SALES_EMP;
REVOKE ALL ON EMPLOYEE FROM PUBLIC;
GRANT SELECT,INSERT,UPDATE,DELETE,REFERENCES ON EMPLOYEE TO PUBLIC;
COMMIT;

/* # Disable encryption
CONNECT 'c:\data\employee_col_encrypt.ib' USER 'sysdba' PASSWORD 'masterkey';
ALTER DATABASE DECRYPT;
COMMIT;

CONNECT 'c:\data\employee_col_encrypt.ib' USER 'sysdso' PASSWORD 'sysdso';
DROP ENCRYPTION hr_key RESTRICT;
COMMIT;
ALTER DATABASE SET NO SYSTEM ENCRYPTION PASSWORD;
COMMIT;
*/


